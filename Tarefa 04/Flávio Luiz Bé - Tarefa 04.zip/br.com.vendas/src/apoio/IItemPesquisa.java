/**
 * @author Flavio
 */
package apoio;

public interface IItemPesquisa {
    
    public void definirValor(String valores[], String itemPesquisa);

}
